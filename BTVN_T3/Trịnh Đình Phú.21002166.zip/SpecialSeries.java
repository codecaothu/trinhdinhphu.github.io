package BTVN_T3;

import java.util.Scanner;

public class SpecialSeries {
    public static double SumOfSeries(double x, int numTerms) {
        if (numTerms == 1) {
            return x;
        }
        int maxOdd = numTerms * 2 - 1;
        int maxEven = numTerms * 2 - 2;
        double powerTerm = Math.pow(x, maxOdd) / maxOdd;
        int numerator = 1;
        for (int numMult = maxOdd - 2; numMult > 2; numMult -= 2) {
            numerator *= numMult;
        }
        int denominator = 2;
        for (int numMult = maxEven; numMult > 2; numMult -= 2) {
            denominator *= numMult;
        }
        return powerTerm * numerator / denominator + sumOfSeries(x, numTerms - 1);
    }

    public static void main(String[] args) {
        try {
            Scanner sc = new Scanner(System.in);
            int numTerms = sc.nextInt();
            double x = sc.nextDouble();
            System.out.println(sumOfSeries(x, numTerms));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
